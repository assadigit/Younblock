# Round 3: show how much data every session used

Usage: you are working in the Younblock repo (Go + Wails v2 + Svelte + TypeScript). Everything you need is in `younblock-ui/round-3/`. Read `feature-spec.md` first. The code in this folder is a TESTED reference and it already contains all round-2 fixes. If round-2 was not applied yet, apply this folder instead of round-2.

## The one thing to find out first
Find where Younblock's proxy copies data between the browser and the internet (the tunnel or relay loop). The usage can only be counted there.
- If the relay is in this app's Go code: continue.
- If the browser connects to the internet directly and Younblock only changes DNS or settings: bytes cannot be counted. Make `Bytes()` return `-1, -1` (or do not implement it). The screen then hides the feature. Tell me clearly that this is the situation, and stop adding Go counting.

## Steps (do all of them, no questions unless something does not fit)
1. **Go files:** copy `go/usage.go`, `go/byte_totals.go` and the three `_test.go` files into the project root. For `go/ui_bridge.go`: if the repo's copy has no local edits, replace it; otherwise merge in the new parts (Snapshot fields, `ByteCounter`, `SetUsageStore`, `GetUsage`, `ClearUsage`, session handling in `runStart` / `Disconnect` / `refreshStats`).
2. **Count the bytes:** add a `ByteTotals` field to the real engine. In the relay loop wrap the two copy directions, exactly like the comment at the top of `byte_totals.go`:
   `io.Copy(totals.DownWriter(client), remote)` for internet to browser, `io.Copy(totals.UpWriter(remote), client)` for browser to internet. Add the engine method `Bytes() (int64, int64) { return e.totals.Snapshot() }`. Count every tunnel, including the ones for DNS-over-HTTPS if Younblock relays them itself (they are Younblock's own traffic).
3. **Wire it in (adapt names to the repo):**
```go
func NewApp() *App {
	a := &App{}
	a.bridge = NewBridge(newYounblockEngine(), func(s Snapshot) {
		if a.ctx != nil {
			runtime.EventsEmit(a.ctx, "younblock:status", s)
		}
	})
	if path, err := DefaultUsagePath(); err == nil {
		if store, err := NewUsageStore(path); err == nil {
			a.bridge.SetUsageStore(store)
		}
	}
	return a
}
func (a *App) GetUsage() UsageSummary { return a.bridge.GetUsage() }
func (a *App) ClearUsage() error      { return a.bridge.ClearUsage() }
```
   `shutdown` must still call `a.bridge.Disconnect()` so a running session is saved when the app closes.
4. **Frontend:** copy these as they are: `lib/format.ts`, `lib/types.ts`, `lib/Timer.svelte`, `lib/DotRings.svelte`, `lib/PowerPill.svelte`, `lib/icons.ts`, `tokens.css`, `app.css`. MERGE (keep the repo's own content, add the new parts): `lib/backend.ts` (keep the repo's real names in CONFIG; add `goGetUsage: 'GetUsage'`, `goClearUsage: 'ClearUsage'`), `lib/MenuSheet.svelte` (keep the repo's About / How it works / Help / Other websites wording and the "Created by ChitaCodes" line; add the Data usage section and the two new props), `App.svelte` (keep the real app name, logo, version; add the usage lines, the last-session line, and the MenuSheet props `loadUsage` and `clearUsage`). `npm install lucide-svelte` if it is not installed.
5. **Build and test:**
   - `go vet ./... && go test -race ./...` must pass.
   - `cd frontend && npm run build` must have no errors (run `npx svelte-check` too).
   - `pip install playwright pillow && python3 -m playwright install chromium`, then from the repo root run all three: `YB_DIST=frontend/dist python3 younblock-ui/round-3/tests/test_v3.py`, `.../test_v2.py`, `.../test_ui.py`. All must print `ALL PASSED`.
6. **Run `wails dev` and check by hand:** connect, browse some YouTube for a minute, see "N MB used" climb; disconnect and see "Last session: …"; open the menu and see the session in the list; close the app while connected, start it again, and confirm that session was recovered into the history; click Clear history, Keep, then Delete.
7. Do not commit or push.

## Acceptance checklist (report PASS/FAIL for each)
1. While connected: "X used" with a download/upload split, growing live.
2. After disconnect: "Last session: size · length" under "Not Connected".
3. Menu shows Today / This month / All time and up to 10 sessions, newest first.
4. Clear history asks first; Keep changes nothing; Delete empties the list and removes the Last-session line.
5. A cancelled or failed connection creates no session.
6. Closing the app while connected still saves the session (or recovers it on the next start).
7. If the engine cannot count bytes, no usage lines appear and nothing is saved.
8. The history file exists at the Windows AppData location and contains no website names, only times and byte totals.
9. No overlap or scrollbars at 320×560, 356×625 and 360×760.
10. All Go and Python tests pass; the build is clean.

## Don't
Show a number the engine did not count. Send the history anywhere. Add website names or addresses to the history. Remove the breathing pulse of the green rings.

# Feature spec: data used by every session

Usage: this is the definition of the feature. `agent-instructions.md` says how to build it. The code in this folder is a tested reference.

## What you get
1. **While connected:** under the timer, the data this session has used, for example **2.10 GB used**, with download and upload split below it (↓ 1.80 GB ↑ 300 MB). It counts up live.
2. **When not connected:** the line under "Not Connected" says `Last session: 2.66 GB · 1 h 1 min`.
3. **In the menu (top section "Data usage"):** totals for Today, This month and All time, the last 10 sessions (date, length, size), and a "Clear history" button with a confirmation.

## Decisions
| Question | Decision | Why |
|---|---|---|
| What is counted | Bytes that pass through Younblock's proxy, both directions | Younblock can only count what it relays |
| Units | Decimal: 1 GB = 1,000,000,000 bytes | Internet providers bill this way |
| Number format | 3 significant digits: 2.10 GB, 12.3 MB, 123 MB, 999 B | The live number visibly ticks |
| Session | From "Connected" until disconnect. Starts at zero every time | "Every session" |
| Cancelled connection / failed connection | Not a session, nothing saved | Nothing was used |
| Saved where | One JSON file on this PC: `%AppData%\Younblock\usage.json` (Windows). Never sent anywhere | About says "no analytics": this keeps it true |
| History size | Newest 500 sessions | Small file, plenty of history |
| App crash or power loss | The running session is saved every 15 s and recovered on the next start | No lost sessions |
| "Today" / "This month" | Calendar day and month in the PC's time zone, by session end time | Matches how people think |
| Accuracy | Menu says: "Counts the data that passes through Younblock, saved only on this PC. Your internet provider may count a little more." | Honest: headers and other apps are not counted |
| Engine cannot count | Send -1: the usage lines are hidden and nothing is saved. Never show a made-up 0 | No false numbers |
| Live speed (Mb/s) | Off by default (`SHOW_SPEEDS = false` in App.svelte) | The total is what matters |

## Data contract (Go sends JSON, the screen reads it; names must match exactly)
`Snapshot` gains: `downBytes`, `upBytes` (this session, bytes, -1 = unknown) and `lastSession` (optional).
`SessionRecord`: `startMs`, `endMs` (Unix ms), `downBytes`, `upBytes`.
`UsageSummary`: `sessions` (newest first, max 10), `sessionCount`, `todayBytes`, `monthBytes`, `allTimeBytes`.
New Go methods the screen calls: `GetUsage()` and `ClearUsage()`.

## Screen rules
- Usage lines show only while connected and only if both byte numbers are 0 or more.
- Menu opens → the screen asks Go for `GetUsage()` every time (always fresh).
- Clear history: first click shows "Delete the whole history?" with Delete (red) and Keep. Only Delete clears. After clearing, the "Last session" line disappears too.
- Empty history: "No sessions yet. Every session you run will be listed here."
- If `GetUsage()` fails: "Could not read the usage history." The rest of the menu still works.
- Layout must stay clean at 320×560, 356×625 and 360×760: nothing overlaps, no scrollbars.

## Not in this version
Per-website breakdown, data limits or warnings, export to a file, charts. Say so if you want any of them.

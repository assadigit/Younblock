# Other-websites test plan

Usage: run this yourself (or tell your agent to guide you) to find out which websites besides YouTube Younblock really opens. Until a website passes, the app says only "some other blocked websites open too, but that is still being tested". When sites pass, add their names to `VERIFIED_SITES` in `MenuSheet.svelte` and the menu will show "Confirmed so far: …".

## Rule
A website counts as CONFIRMED only if: (a) it is really blocked on your network WITHOUT Younblock, and (b) it opens correctly WITH Younblock, on at least two different days (or two different networks). One lucky success does not count.

## How to test one website
1. In Chrome, with Younblock disconnected, open the website. Write down what happens: opens normally, or fails (error page, endless loading, partial page with missing images or video).
2. If it already opens normally, it is not blocked: stop. It cannot prove anything.
3. Connect Younblock (wait for "Connected"). Reload the website with a hard refresh (Ctrl+F5).
4. Check the page fully: text, images, a video or a login if it has one. Partly loading = PARTIAL.
5. Disconnect and repeat step 1 once more, to be sure it is Younblock that made the difference.
6. Write the result in the table below.

## Result table (copy and fill)
| Website | Blocked without Younblock? | Result with Younblock (OK / PARTIAL / FAIL) | Date | Network (home, mobile data, …) | Notes |
|---|---|---|---|---|---|
| | | | | | |

## Good to know
- Younblock only splits the first message of each connection and uses a safe DNS lookup. Websites blocked in other ways (by IP address, or by their content) will fail. That is expected, not a bug.
- Sites that mix many servers (video sites, big social sites) often show PARTIAL: record it as PARTIAL, not OK.
- Only Chrome is supported, so test only in Chrome.

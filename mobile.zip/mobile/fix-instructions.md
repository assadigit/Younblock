# Round 2: fix instructions for the agent

Usage: you are improving the Younblock screen that already exists in this repo. Everything you need is in `younblock-ui/round-2/`. The code there is a TESTED reference version of the fixed screen (Svelte 4.2). Your job is to apply it to the real project, keep the project's own content, and prove it works.

## Why (read first)
1. The window is about 356×625, but the old layout was locked to a 360×760 shape, so the whole UI shrank to ~82% (hint text became 9px). Fix: scale by window WIDTH, stack the layout top to bottom.
2. The countdown digits overlapped: each digit box was 0.68em wide, but the font's widest digit ("0") is 0.76em. Fix: 0.80em boxes.
3. In Connected mode the ring dots ran through the hint text, and the hint was faint. Fix: smaller rings that stop above the hint, bigger and brighter hint.
4. The power icon and other icons were hand-drawn. Fix: real Lucide icons through one file, `src/lib/icons.ts`.
5. The menu button used a four-dot glyph on the left. Fix: Lucide "Ellipsis" (…), top right.
6. The menu's red close circle floated half outside the sheet. Fix: a fixed header INSIDE the sheet (title left, neutral X right, 44px), body scrolls underneath.
7. "0 Kb/s / 0 Kb/s" while connected is false information. Fix: if the Go engine cannot measure speeds it sends -1, and the screen hides the speed line. A bare "762 ms" ping also gets a word: Good / OK / Slow.
8. New text: "Created by ChitaCodes" in About, and an "Other websites" section that says honestly it is still being tested.
9. KEEP: the slow breathing pulse of the green rings (it is liked). Do not remove or slow it. Keep `--dur-pulse: 2.4s`, the per-ring delay, and the faster pulse while busy.

## Steps (do all of them, no questions unless something does not fit)
1. In `frontend/`: run `npm install lucide-svelte`. (Peer range is Svelte 3, 4 or 5.) If the build later fails on the icons, install `@lucide/svelte` instead and change only the import paths in `src/lib/icons.ts`.
2. Compare each file in `younblock-ui/round-2/frontend/src/` with the repo's `frontend/src/`. Copy these over as they are: `tokens.css`, `app.css`, `lib/Timer.svelte`, `lib/DotRings.svelte`, `lib/PowerPill.svelte`, `lib/icons.ts`, `lib/format.ts`, `lib/types.ts`.
3. MERGE (do not blindly overwrite) these, because the repo has project-specific content:
   - `lib/backend.ts`: take the reference, but keep the real names in the CONFIG block (Go struct and method names) as they are in the repo.
   - `lib/MenuSheet.svelte`: take the reference STRUCTURE (header with title + X, scrolling body, focus handling). Put the repo's existing About / How it works / Help wording into the `SECTIONS` array (the repo's wording wins over the demo text). Then add: the line `Created by ChitaCodes` (the `CREDIT` constant, shown with the version in About), and the `Other websites` section exactly as in the reference.
   - `App.svelte`: take the reference layout. Keep the repo's real values: app name, logo (`LOGO_URL`), and wire `APP_VERSION` to the repo's existing version source if there is one (the About text showed 1.6.3).
   - `main.ts`: leave the repo's mount code. Make sure the three imports (font, tokens.css, app.css) are there.
4. Go: copy `go/ui_bridge.go` over the repo's copy only if the repo's copy has no local changes; otherwise apply just the doc-comment change about -1 (unmeasurable). Then make the real engine return `-1` for speeds it does not truly measure (and `-1` for ping it does not truly measure). Never return a made-up 0. Run `go vet ./... && go test -race ./...`.
5. Wails window (main.go): inner size 360×640 recommended; set `MinWidth: 320`, `MinHeight: 560`. Any inner height from 560 up works now.
6. Build: `cd frontend && npm run build` must finish with no errors; run `npx svelte-check` if available and fix warnings.
7. Run the tests (Python): `pip install playwright pillow && python3 -m playwright install chromium`, then from the repo root:
   `YB_DIST=frontend/dist python3 younblock-ui/round-2/tests/test_v2.py` and `YB_DIST=frontend/dist python3 younblock-ui/round-2/tests/test_ui.py`. Both must print `ALL PASSED`. If a test fails because the repo legitimately differs (for example the About wording), adapt the test, not the design, and tell me.
8. Run `wails dev` and look at it yourself in all five situations: Not Connected, Connecting (click, then cancel), Connected, Connected with the menu open, and Error. Compare with `younblock-ui/round-2/preview/*.png`.
9. Do not commit or push. Leave the changes in the working tree.

## Acceptance checklist (report PASS/FAIL for each)
1. Digits of the countdown never touch; all digits have equal width.
2. In Connected mode no ring dot touches the hint line; hint text is at least 11px and clearly readable.
3. Power, menu, chevron, arrow and close icons are all Lucide icons (no hand-drawn paths except the logo and the faint play mark).
4. The menu button shows "…" at the top right and is at least 44px.
5. The menu sheet has its X inside the header, at least 44px, neutral (not red); the header stays fixed while the body scrolls; Escape and tapping outside close it.
6. About shows "Created by ChitaCodes". The "Other websites" section is present.
7. While connected, if speeds are unavailable the speed line is hidden; ping shows "Ping N ms · Good/OK/Slow".
8. The green rings still breathe slowly in Connected mode.
9. At inner sizes 356×625, 360×760 and 320×560 there is no scrollbar and nothing is cut off.
10. `go test -race` and `npm run build` pass.

## Don't
Add flags, maps, upsells or new accent colors. Hardcode colors (use `tokens.css`). Remove the pulse. Show a speed or ping number the engine did not really measure.

# Round 2 audit (roast + mentor calls)

Usage: the reasoning behind `fix-instructions.md`. Screens reviewed: Not Connected, Menu, Connected (window about 356×625). Scope: desktop Wails app, English only, audience: you and friends.

## Verdict
The idea works: red control + green state, big pill, calm layout. The craft let it down in five places that people notice in the first minute: a shrunken UI, touching digits, a hint printed over dots, a floating close button, and drawn icons.

## Findings
| # | Severity | Finding | Cause | Fix |
|---|---|---|---|---|
| 1 | Major | Whole UI is ~82% of its designed size; hint text ≈ 9px | Layout locked to a 360×760 shape, window is 356×625 | Scale by width, stack layout vertically (spec error, now fixed) |
| 2 | Major | Countdown digits overlap, colons uneven | Digit box 0.68em, widest digit 0.76em | Boxes 0.80em |
| 3 | Major | Hint is printed over ring dots and is faint | Rings reached the hint's row; hint 11px at 62% white | Rings stop 2.9rem below the pill, hint 3.4rem; 12px at 82% white |
| 4 | Major | "0 Kb/s / 0 Kb/s" while connected | Fake zero instead of "unknown" (Nielsen: visibility of system status) | Engine sends -1, screen hides the line |
| 5 | Major | Close button half outside the sheet, red glowing, overlapping the scrollbar | Floating absolute button; red should mean "control", not "dismiss" | Header inside the sheet, neutral 44px X |
| 6 | Minor | Power icon is drawn: stem tilted, arc uneven | Hand-made SVG | Lucide Power |
| 7 | Minor | Four-dot glyph, top-left, 40px | Copied from the reference | Lucide Ellipsis, top-right (Jakob's law), 44px (Fitts) |
| 8 | Minor | "Ping 762 ms" with no meaning | Number alone | "Ping 762 ms · Slow" (thresholds in config) |
| 9 | Nitpick | Menu text is long with no credit | Content | Short sections, credit line, "Other websites" honesty line |

## 13 core principles (quick score)
Alignment ✅ · Contrast 🟡 (hint) · Balance ✅ · Hierarchy ✅ · Color ✅ (red/green governed) · White space 🟡 (empty top in Not Connected, softened by the faint mark) · Proportion ✅ · Repetition ✅ · Rhythm 🟡 (digit spacing) · Movement ✅ (breathing rings) · Emphasis ✅ · Proximity 🟡 (ring dots near hint) · Unity ✅

## What is good (keep)
The breathing rings, the thumb physics and drag, red thumb = control, "It is not a VPN" honesty in About, focus rings, the stable status block.

## Not applicable
RTL / Farsi (English only). Trademark worry about the play-mark logo (private tool for friends); revisit if it ever goes public.

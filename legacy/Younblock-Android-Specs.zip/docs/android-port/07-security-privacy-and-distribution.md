# 07 — Security, Privacy, and Distribution

**Status:** Mandatory design checklist. Reassess against actual implementation, current Android policy, and selected distribution channel before release.

## 1. Truthful product claims

The supplied project description says Younblock is not a conventional VPN, does not hide the user's IP address, and adds no encryption of its own. Preserve this description unless code changes intentionally add a new capability and the threat model is reviewed.

- Do not describe the app as anonymous, private by default, or IP-masking unless that is technically true.
- If Android's `VpnService` is used only to route traffic into a local userspace engine, explain that it is a local traffic-routing interface and whether any remote server is involved. Do not imply the standard consumer remote VPN model.
- State which applications and protocols are routed, bypassed, unsupported, or unverified.
- State that secure DNS providers receive the DNS information inherent in queries made through them, consistent with the actual implementation.
- Do not claim all network metadata is hidden. HTTPS encryption and routing behavior need precise explanation.

## 2. Permission and consent

If a VPN-based design is selected:

- Explain why the app requests the Android VPN permission before showing the system consent prompt.
- Request permission only in response to a clear user action and handle rejection/cancellation.
- Respect the platform's restrictions on VPN service establishment and competing VPNs.
- Provide a clear way to stop the service and show when it is active.
- Use the currently required foreground-service/notification design for the chosen Android API range; verify current requirements rather than relying on memory.
- Stop or reconcile service behavior when permission is revoked or the system stops the service.

If a browser-specific routing mode is selected, describe its narrower scope and any manual proxy setup instead of requesting unnecessary VPN permission.

## 3. Traffic processing and failure safety

- Default to fail-safe, documented behavior if routing or engine components fail.
- Prevent recursive interception of Younblock's own upstream connections.
- Avoid DNS or IPv6 leaks caused by partial route configuration; either support the family correctly or document and implement a clear exclusion strategy.
- Never report Connected while traffic is bypassing the intended engine because of a failed route.
- Restore ordinary routing when disconnected according to Android behavior.
- Limit logs to what is required for diagnosis. Avoid logging full URLs, query strings, TLS payloads, authentication details, or user browsing contents by default.
- Do not disable TLS certificate validation to make upstream connections succeed.
- Put timeouts, bounded retries, resource limits, and cancellation on all network operations.
- Keep user configuration and sensitive diagnostics in app-private storage with appropriate permissions.

## 4. Threat model to document

At minimum assess:

- Malicious or compromised DNS provider.
- Network attacker observing metadata or altering unencrypted traffic.
- Local application receiving sensitive routing privileges.
- Malformed DNS responses and hostile packet/stream inputs.
- Memory exhaustion or connection-flood behavior.
- Traffic leakage during startup, error, reconnect, or shutdown.
- Dependencies with vulnerabilities or incompatible licenses.
- Untrusted values entered into provider configuration.
- Debug logs and crash reports unintentionally containing browsing data.

State the threat model's limits clearly. Younblock's stated goal is not to provide a general-purpose security tunnel.

## 5. Data handling and privacy disclosure

Before release, answer based on the actual implementation:

- Does the application collect analytics or crash reports?
- Does any data leave the device besides traffic needed to perform DNS queries and upstream connections?
- Which DNS providers are configured by default, and what data do they receive?
- What logs are stored, where, and for how long?
- Are provider selections or diagnostics synced anywhere?
- Can users view and clear diagnostic data?
- Does the app access other apps' traffic, and under what exact scope?

If no collection is implemented, verify that statement against source and third-party SDK behavior before publishing it.

## 6. Android permissions and platform behavior

Create an inventory of every permission and manifest attribute. For each, document the feature requiring it, whether it is runtime/system consent, how denial is handled, and whether the permission is necessary.

Do not add unrelated permissions for convenience. Verify current Android documentation for foreground services, notification behavior, API restrictions, and VPN requirements for the selected minimum/target API levels.

## 7. Dependencies and licenses

For every new dependency, record:

- Name, pinned version, repository, license, maintenance status.
- Why it is needed and alternatives considered.
- Compatibility with target ABIs/API levels.
- Transitive/native dependencies and supply-chain implications.
- Any attribution/notice obligations.

Pay special attention to Go packet-processing/transparent proxy libraries, native bindings, copied code, and distribution requirements.

## 8. Distribution and signing

- Build a debug APK for internal testing.
- Build and sign a release APK with a real, securely managed signing key when available.
- Never generate pretend production credentials or commit private signing keys.
- Verify current Google Play and other distribution-channel policies before publication, especially rules relevant to VPN/traffic-routing apps, disclosure, foreground operation, and user consent.
- Ensure release notes accurately list supported Android versions, traffic scope, limitations, and known issues.
- Keep build provenance and checksums for artifacts.

## 9. Release-blocking checklist

- [ ] Permission rationale and service state are understandable.
- [ ] App does not overstate IP hiding, encryption, VPN, or universal support.
- [ ] DNS and traffic scope are documented accurately.
- [ ] Startup and stop paths are tested for leakage and cleanup.
- [ ] IPv4/IPv6 and TCP/UDP support claims match test results.
- [ ] Sensitive logs/configuration are minimized and redacted.
- [ ] Dependency/license review completed.
- [ ] Android platform and distribution requirements rechecked against current primary sources.
- [ ] APK signing, version, and checksums verified.
- [ ] Known limitations are disclosed in-app or in release documentation.

# 09 — Agent Handoff and Starting Checklist

**Status:** Operational guide for coding agents. Update after Phase 1 and again after implementation.

## If starting Phase 1 (audit/spec completion)

1. Inspect `git status --short --branch`, branch, latest commit, and remotes. Preserve unrelated/uncommitted user changes.
2. Read all files under `docs/android-port/` before coding.
3. Read the actual README/changelog and trace source files referenced by `01-current-architecture-audit.md`.
4. Complete the audit with exact paths, packages, symbols, dependency versions, and current build/test results.
5. Research current primary Android/Go documentation for any API or toolchain claim that affects the decision.
6. Run a feasibility comparison and a minimal proof of concept if the environment supports it. Keep this phase documentation-only; do not add application implementation or build an APK.
7. Update the architecture recommendation, decisions, risk register, requirement traceability, and implementation roadmap.
8. Validate local Markdown links and diagrams; inspect `git diff --check` and `git diff`.
9. Commit and push documentation only if authorized and available. Otherwise leave clean, reviewable files and state what could not be published.
10. Report verified findings, open blockers, final architecture decision, and the first implementation milestone.

## If starting Phase 2 (implementation)

1. Read every spec file before making changes, particularly the finalized feasibility report, target architecture, decisions, roadmap, and build/test plan.
2. Inspect the working tree and ensure the Phase 1 documents are present. If the documents are only this initial baseline, finish or resolve any marked **To verify** architecture gate before building the complete Android app.
3. Read every source file named in the audit and validate high-risk assumptions against the current source.
4. Begin with the first approved implementation milestone, not a new broad planning exercise. The first code milestone should be the minimal Android shell and Go-bridge prototype that proves toolchain/API compatibility; then follow the accepted routing proof-of-concept sequence.
5. Make small changes, run relevant tests after each milestone, and preserve Windows/Linux behavior.
6. Stop and document if a critical routing or engine integration assumption fails. Do not fake functionality or silently replace the required product scope.
7. Build the debug APK at minimum once the approved code path is implementable, verify its actual existence and metadata, and report tests honestly.
8. Update specs with implementation reality, limitations, exact commands, artifact path/checksum, and commit/push status.

## Environment / execution honesty

- If network access, Android SDK, emulator, device, signing key, repository write access, or an essential dependency is unavailable, say so precisely.
- Do not claim source inspection, test success, APK creation, upload, or push without evidence.
- Do not commit secrets, signing keys, user settings, or private diagnostics.
- Do not undo unrelated working-tree changes to achieve a clean diff.

## Current handoff fields (complete at each session boundary)

- Phase completed: **To fill**.
- Branch and commit: **To fill**.
- Files changed: **To fill**.
- Tests run and actual results: **To fill**.
- Current architecture decision / confidence: **To fill**.
- Blocking questions: **To fill**.
- Exact next task: **To fill**.

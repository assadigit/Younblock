# 05 — Implementation Roadmap

**Status:** Proposed milestones. Do not skip the technical feasibility gates because they determine whether the product is viable with the existing engine.

## Phase 1: audit and finalize the blueprint (documentation-only)

### M0 — Repository baseline and source map

Tasks:
- Inspect Git status, branch, latest commit, and remotes.
- Inventory Go packages, Wails runtime, frontend, scripts, tests, and release workflows.
- Trace Connect → engine → relay → DNS/TLS logic → OS proxy → status.
- Record baseline desktop build/test results.
- Complete `01-current-architecture-audit.md` with source evidence.

Exit criteria:
- No unverified source-path claims remain in the audit.
- Desktop build and test instructions are known or environment blockers are recorded.
- No application code has been changed.

### M1 — Architecture feasibility decision

Tasks:
- Compare browser-specific proxy, Android proxy, and `VpnService`/TUN approaches.
- Identify the actual protocol accepted by the current relay.
- Audit Go dependencies and Android ABI support.
- Compare Kotlin-native UI versus Svelte-in-WebView.
- Define a proof-of-concept that tests the highest-risk assumptions.

Exit criteria:
- A primary design and fallback are documented.
- Every P0 risk has either evidence-backed mitigation or an explicit no-go.
- ADRs are updated.

### M2 — Finalize implementation specification

Tasks:
- Complete feature prioritization and traceability.
- Finalize APIs, module boundaries, state transitions, error mapping, storage, and cleanup.
- Finalize build/test matrix and supported-device declaration.
- Write a first implementation checklist.

Exit criteria:
- Phase 2 can begin without another broad architecture discovery session.

## Phase 2: implementation and APK delivery

### M3 — Build scaffolding and platform-neutral engine boundary

Tasks:
- Add the Android Gradle project/module using verified supported tool versions.
- Add the smallest platform-neutral engine API and binding layer selected in the ADR.
- Add a minimal Android UI/app shell and app metadata.
- Keep desktop builds unchanged.

Tests:
- Clean Android build.
- Host Go unit tests.
- Minimal Kotlin-to-Go initialization/health/stop test.

Exit criteria:
- A debug APK builds and launches; bridge works without network routing yet.

### M4 — Prove the routing path

Tasks:
- Implement the selected browser proxy or VPN/TUN adapter.
- Integrate packet/stream processing only as required by the approved design.
- Implement DNS, stream routing, loop prevention, and the supported protocol matrix.
- Add safe failure and cleanup behavior.

Tests:
- Controlled test destination and local integration endpoint.
- Correct handling of DNS failures, connection resets, timeouts, backgrounding, and stop.
- Explicit tests for each declared supported protocol/family.

Exit criteria:
- The core traffic path has an end-to-end test, not just a UI-level success state.

### M5 — Core connection lifecycle and health reporting

Tasks:
- Implement permission flow, service lifecycle, actual state reconciliation, diagnostics, health check, retry bounds, and cleanup.
- Prevent duplicate start operations and stale UI state.

Tests:
- Partial-start failure injection at every startup step.
- Repeated connect/disconnect.
- Service/process interruption and network switching.

Exit criteria:
- No known route/service leak or misleading Connected state in test scenarios.

### M6 — Settings and mobile UX

Tasks:
- Implement required settings and persistent, versioned configuration.
- Implement actionable error messages, status UI, help/privacy explanation, and version/about.
- Make the UI usable on narrow screens and accessibility font settings.

Tests:
- Configuration migration and invalid input.
- Rotation/resume, permission denial, and accessibility/manual UI checks.

Exit criteria:
- P0 and approved P1 features meet `02-requirements-and-feature-matrix.md`.

### M7 — Regression, hardening, and release preparation

Tasks:
- Run the complete test matrix.
- Run desktop regressions on the same baseline commands.
- Audit dependencies and licenses.
- Review privacy disclosures, Android permissions, app signing, and distribution-specific requirements.
- Measure resource behavior on an actual device if available.

Exit criteria:
- No unresolved P0 issue; all remaining limitations are recorded and user-visible.

### M8 — Package, verify, and hand off

Tasks:
- Build a debug APK; build a release APK if signing is configured.
- Verify the actual artifact path, application ID, version, architecture, and checksum.
- Install and smoke-test on an emulator/device if available.
- Update documentation and release notes.
- Commit/push changes only when repository access allows, preserving pre-existing changes.

Exit criteria:
- The final report distinguishes build success from emulator/device and network verification.
- The actual APK is delivered if the build succeeded.

## Dependency order / critical path

```mermaid
flowchart TD
    M0[Audit current source] --> M1[Feasibility proof and ADR]
    M1 --> M2[Finalize specification]
    M2 --> M3[Android scaffold and Go bridge]
    M3 --> M4[Prove real routing path]
    M4 --> M5[Lifecycle and health state]
    M5 --> M6[Settings and UX]
    M6 --> M7[Regression and hardening]
    M7 --> M8[APK build and handoff]
```

## Change-control rules

- Keep commits scoped and inspect diffs before committing.
- Do not mix Android work with unrelated UI/product refactors.
- Do not overwrite dirty work or force-push.
- If a milestone changes a major decision, update the relevant ADR and affected test plan before continuing.
- Preserve known limitations in release notes; do not mark a task complete merely because code was written.

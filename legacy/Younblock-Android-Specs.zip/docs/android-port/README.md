# Younblock Android Port — Specification Pack

**Repository:** <https://github.com/assadigit/Younblock>  
**Documentation location intended for the repository:** `docs/android-port/`  
**Status:** Initial planning baseline — source audit and feasibility validation are still required.

## Purpose

This document set defines how to investigate, design, implement, test, and package an Android edition of Younblock while protecting the existing Windows and Linux applications.

The pack is based on the project description supplied for this task. The repository source could not be independently inspected while preparing this initial pack, so repository-specific facts, exact package names, API signatures, dependencies, and supported behaviors must be verified by the coding agent. These documents intentionally distinguish known product context from recommendations and open questions. They must not be treated as proof that any implementation has already been validated.

## Intended deliverable

An installable Android APK that preserves Younblock's core purpose: help YouTube work on networks that apply certain forms of hostname-based filtering, using the existing networking logic where feasible. The Android edition must be honest about traffic coverage, DNS behavior, privacy, and limitations. It must not describe itself as a remote VPN service if it only processes traffic locally and does not tunnel it to a remote VPN gateway.

## Current known context

The provided project description says Younblock is a Windows/Linux Go application with a Svelte/TypeScript UI. It describes a local relay, configurable secure DNS, TLS ClientHello splitting, platform-specific proxy configuration, connection checks, automatic recovery, settings, and diagnostics. It also explicitly says the product is not a conventional VPN, does not hide the user's public IP, and adds no encryption of its own. These details are starting assumptions to verify against the repository and current product behavior.

## Reading order

1. [`01-current-architecture-audit.md`](01-current-architecture-audit.md) — establish what exists today.
2. [`02-requirements-and-feature-matrix.md`](02-requirements-and-feature-matrix.md) — define the target behavior.
3. [`03-android-technical-feasibility.md`](03-android-technical-feasibility.md) — test the risky platform and networking assumptions.
4. [`04-target-architecture.md`](04-target-architecture.md) — settle the system design after the feasibility gate.
5. [`05-implementation-roadmap.md`](05-implementation-roadmap.md) — implement in validated milestones.
6. [`06-build-and-test-plan.md`](06-build-and-test-plan.md) — define repeatable builds and evidence.
7. [`07-security-privacy-and-distribution.md`](07-security-privacy-and-distribution.md) — handle trust, permissions, and publication.
8. [`08-architecture-decisions.md`](08-architecture-decisions.md) — record decisions and changes.
9. [`09-agent-handoff.md`](09-agent-handoff.md) — session handoff and first actions.

## Non-negotiable project rules

- Do not assume that Wails itself can run on Android. Separate portable Go functionality from desktop framework and operating-system integration.
- Do not assume Android exposes a general system-proxy control equivalent to Windows or Linux.
- Do not equate opening a `VpnService` TUN interface with successfully forwarding TCP, UDP, DNS, IPv4, and IPv6 traffic. The packet-processing architecture must be explicit and tested.
- Do not state that traffic is protected, encrypted, hidden, or routed unless the implementation proves that claim.
- Do not regress desktop builds. Android-specific code should be isolated with explicit package boundaries and appropriate build constraints.
- Do not invent source paths, functions, test results, SDK versions, device support, or successful build outcomes. Verify and cite actual evidence in the documents.
- Do not let a UI display “Connected” unless the relevant service has successfully initialized and a real connectivity check passes.
- Preserve the user's existing local changes and inspect Git status before modifying the repository.

## Required initial investigation

The coding agent must perform the actual source audit and update these documents with file paths, package names, functions, dependency versions, test commands, evidence, and exact limitations. Mark each statement as one of:

- **Verified** — directly confirmed from code, repository metadata, a reproducible test, or authoritative documentation.
- **Recommendation** — proposed design, not yet implemented.
- **Assumption** — plausible but not confirmed.
- **Open question** — requires a test, user/product decision, or external constraint check.

The source audit and feasibility proof-of-concept are entry gates, not optional documentation polish. If evidence changes a recommendation, update this pack before continuing.

## Phases

### Phase 1 — Audit and finalize specifications

Read the repository, verify this baseline, compare technical options, settle the architecture, complete the traceability matrix, and write a practical implementation plan. Do not implement the Android application or build an APK in this phase.

### Phase 2 — Implement and build

Read the completed specs and handoff, implement the selected architecture in milestones, run tests, attempt a real APK build, verify the produced artifact, and update documentation with actual results. If a critical assumption fails, stop pretending it works: document the blocker and use the documented fallback or revise the ADR with evidence.

## Official reference starting points

Verify the current versions and relevant requirements when implementing; these links are entry points rather than proof of compatibility:

- Android VPN: <https://developer.android.com/develop/connectivity/vpn>
- Android foreground services: <https://developer.android.com/develop/background-work/services/fgs>
- Android app architecture: <https://developer.android.com/topic/architecture>
- Android app signing: <https://developer.android.com/studio/publish/app-signing>
- Go mobile tooling: <https://pkg.go.dev/golang.org/x/mobile/cmd/gomobile>
- Go build constraints: <https://pkg.go.dev/cmd/go#hdr-Build_constraints>
- Wails project and supported platforms: <https://github.com/wailsapp/wails>

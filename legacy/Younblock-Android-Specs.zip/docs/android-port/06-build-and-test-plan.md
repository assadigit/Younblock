# 06 — Build and Test Plan

**Status:** Baseline validation plan. Exact commands, SDK versions, Gradle versions, ABIs, and API levels must be chosen after dependency and compatibility checks.

## 1. Reproducibility requirements

The project must document a clean-checkout build path. Avoid “works on my machine” assumptions. Pin mutually compatible toolchain versions in standard project configuration where appropriate and use the repository's wrapper scripts. Do not hard-code local SDK paths or credentials.

Record these values when finalized:

| Item | Selected value | Why | Evidence/date |
|---|---|---|---|
| Minimum Android API | To verify/decide | Engine dependencies and product reach | To add |
| Target/compile API | Current policy-compatible value to verify | SDK/policy requirements | To add |
| Android ABIs | At least one validated ABI; likely arm64-v8a first if supported | Device reach and Go/native dependency support | To add |
| JDK version | To verify | Gradle/Android plugin compatibility | To add |
| Android Gradle Plugin | To verify | Compatibility and reproducibility | To add |
| Gradle wrapper | To verify | Compatibility and reproducibility | To add |
| Go version | Based on go.mod and mobile tool support | Dependency compatibility | To add |
| gomobile/JNI strategy | From ADR | Integration constraints | To add |
| Node/package manager | Only if Svelte frontend is included | Frontend build reproducibility | To add |

Do not choose versions based solely on “latest”; select a compatible supported toolchain and document why.

## 2. Build validation layers

### A. Existing Go code

Before changes, run the repository's established commands. Typical candidates to adapt:

```sh
go version
go test ./...
go vet ./...
go build ./...
```

Do not assume `go build ./...` works on all OS targets without platform build constraints. Capture current failures before attributing them to Android changes.

### B. Frontend (only if retained)

Use the existing lockfile and package manager. Run dependency installation in its reproducible/frozen mode where supported, then lint, type-check, tests, and production build. Identify any Wails-generated bindings that need replacement.

### C. Android build

Use the committed Gradle wrapper and exact tasks discovered from the generated project. Typical examples after the project is created:

```sh
./gradlew projects
./gradlew test
./gradlew assembleDebug
```

On Windows, use `gradlew.bat` equivalents. Do not put these in project instructions until validated from the actual module names and toolchain.

## 3. Test layers

### Unit tests

- DNS provider parsing/validation and error classification.
- Traffic/domain classification, if applicable.
- TLS ClientHello stream splitting logic and boundary cases.
- Configuration defaults, serialization, migrations, and invalid settings.
- State transitions and retry/backoff rules.
- Go engine start/stop/cancellation behavior.
- Kotlin error mapping and state projection.

### Bridge tests

- Kotlin/Java calls the actual Go binding.
- Startup error crosses bridge accurately.
- Long-running work can be cancelled/stopped.
- Repeated start/stop does not leak native resources or goroutines.
- Logging and callbacks are safe after Android lifecycle changes.

### Integration/network tests

Use a controlled test server and network to verify actual data paths. Include:

- Supported domain over supported TCP/TLS path.
- Correct resolution through configured DNS provider.
- DNS timeout/refusal/malformed response.
- TLS ClientHello segmentation behavior with packet loss/stream chunk boundaries where relevant.
- Redirect, connection close, read timeout, reset, partial reads and writes.
- Concurrent connections and memory/backpressure.
- IPv4 and IPv6 as advertised.
- UDP and QUIC behavior, including explicitly unsupported behavior.
- Excluded local addresses and own-upstream socket loop prevention.
- Wi-Fi/mobile switch, no internet, captive portal, DNS provider unreachable.
- Stop while requests are active and after partial startup.

Never count a mocked test as proof of an end-to-end public network behavior.

### Android lifecycle/device tests

- Fresh install, upgrade install, launch, permission grant and denial.
- Background app, lock screen, resume app, rotate screen, font scaling.
- Stop from the UI and from the system VPN/network settings when applicable.
- Service/process termination and recovery.
- Network permission/consent revocation.
- Low memory and battery behavior where feasible.
- Notification channel and foreground service behavior at supported API levels.
- App uninstall and expected cleanup behavior.

### Desktop regression tests

Run the same Windows and Linux build/test commands captured before Android edits. Compare logs/results against baseline. Investigate new warnings and failures caused by shared code changes.

## 4. Device and protocol support matrix

Finalize with real results, not assumptions:

| Device/API | ABI | Network | Browser/app | DNS | Traffic family/protocol | Expected behavior | Result |
|---|---|---|---|---|---|---|---|
| Emulator | To verify | Emulator network | Controlled test client | Configured test DNS | IPv4/TCP/TLS | To define | Not run |
| Physical device 1 | To record | Wi-Fi | Selected browser | Selected provider | IPv4/TCP/TLS | To define | Not run |
| Physical device 1 | To record | Mobile data | Selected browser | Selected provider | IPv4/TCP/TLS | To define | Not run |
| Physical device 1 | To record | Dual stack if available | Selected client | Selected provider | IPv6/UDP/QUIC | To define | Not run |

Do not publish support for an API level, browser, ABI, protocol, or network that has not been validated or conservatively scoped.

## 5. APK verification and artifact handoff

For every produced APK, record:

- Exact path and file size.
- Debug/release variant.
- Application ID, version name, version code.
- Supported ABIs and min/target SDK metadata.
- Signing state/certificate identity without publishing private keys.
- SHA-256 checksum.
- Whether it installed successfully.
- Whether it launched successfully.
- Whether core networking was verified on an emulator/device.

Example checksum command:

```sh
sha256sum path/to/app.apk
```

On Windows, use `Get-FileHash path\to\app.apk -Algorithm SHA256`. Adapt to the actual artifact path. Never claim the APK exists before checking it.

A successful Gradle task verifies compilation, not functional networking. The final report must distinguish:

1. Compile/build tested.
2. APK installation tested.
3. UI/lifecycle smoke-tested.
4. Engine integration-tested.
5. Actual target traffic-path tested.

## 6. CI

If feasible, add a CI lane that uses pinned tool versions, runs Go tests, frontend checks (if retained), Android unit tests, and `assembleDebug`. Keep signing material out of CI logs and source control. Treat device-based network tests as a separate capability if unavailable in standard CI.

## 7. Test exit criteria

- All P0 tests pass, or documented no-go/known limitation prevents release.
- Actual traffic coverage matches every user-facing claim.
- Desktop baseline is not silently regressed.
- Build is reproducible on a clean machine with instructions in the repository.

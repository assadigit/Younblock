# 03 — Android Technical Feasibility

**Status:** Feasibility questions and proposed validation. The recommendations below are provisional until source inspection and proof-of-concept testing are complete.

## 1. Key engineering question

The desktop editions reportedly rely on Windows/Linux proxy configuration to get compatible browser traffic into a local relay. Android apps generally cannot be assumed to modify device-wide proxy settings for all apps in an equivalent way. The design must first establish how Android traffic enters Younblock and how that traffic reaches the existing Go engine.

## 2. Routing alternatives

| Approach | Potential benefits | Major constraints / risks | Evidence needed | Initial position |
|---|---|---|---|---|
| A. Browser-specific proxy/configuration | Lowest platform integration effort; may reuse the relay directly | Support limited to specific browsers and their actual proxy features; setup may be manual; browser policies differ; may not route app traffic | Verify browser support, proxy API, Android version behavior, and relay protocol end-to-end | Useful fallback or limited-scope release if product accepts restrictions |
| B. Android Wi-Fi/HTTP proxy configuration | May work in narrow managed or user-configured contexts | Not equivalent to a controllable device-wide proxy; scope and browser support vary; app cannot assume it can change settings silently | Verify exact Android API/control available to ordinary apps and user steps | Do not choose as primary without strong proof |
| C. `VpnService` plus a local userspace packet/network stack and Younblock engine | Can present an Android-supported local VPN interface and route selected/device traffic into app-owned processing | Requires VPN consent, TUN processing, TCP stream/proxy mapping, DNS/UDP/IPv6 decisions, lifecycle handling, no-loop rules, battery/performance work; may need significant new networking code | Working packet/traffic proof of concept, dependency audit, real-device integration tests | Primary candidate for broad transparent routing, but high-risk until proven |
| D. WebView-only YouTube experience | UI and request path can be constrained to a controlled web surface | Not equivalent to supporting the user's installed browsers; may change product promise and login/media behavior; TLS interception is not automatically solved | Product decision and functional proof of YouTube behavior | Product alternative only if narrow scope is explicitly acceptable |

## 3. `VpnService` design caveats

If the local VPN approach is selected:

- A TUN interface supplies IP packets; it does not automatically translate TCP streams to an HTTP/SOCKS relay.
- Specify the userspace stack or forwarding component that parses packets and owns TCP/UDP state. Prefer a maintained library with suitable licensing and Android/Go support to a bespoke packet stack unless there is compelling evidence otherwise.
- Determine whether the existing relay accepts ordinary TCP connections, HTTP proxy requests, SOCKS requests, raw TLS connections, or a different protocol. The bridge architecture depends on the actual answer.
- TLS ClientHello splitting works on a TCP byte stream, not arbitrary individual IP packets. Document where the stream is reconstructed and split, and ensure the chosen routing path can apply the operation without breaking stream ordering or TLS.
- Decide how UDP, HTTP/3/QUIC, DNS over HTTPS, IPv6, local destinations, multicast, tethering, and non-browser app traffic are handled. Unsupported traffic must be excluded or failed in a controlled and disclosed way.
- Prevent routing loops: upstream sockets created by Younblock must not be intercepted by the same TUN route. Verify the correct Android API and routing behavior rather than assuming an exclusion call works in all contexts.
- Handle MTU, fragmentation, half-close, timeouts, connection reset, memory/backpressure, and app/service cancellation.
- Implement a foreground service and notification only as currently required by the selected Android API levels and the desired background behavior. Verify current Android policy and exact service-type requirements.
- Do not add a remote VPN server unless product scope is explicitly changed and privacy claims, infrastructure, and threat model are revised.

## 4. Go engine integration options

Investigate at least these options:

1. **`gomobile bind` / AAR:** can be convenient for exposing a Go library to Java/Kotlin, but exported API restrictions, Go package dependency compatibility, callbacks, build constraints, and Android ABI output must be verified.
2. **c-shared/JNI bridge:** can expose Go functions to native Android code but adds cgo, JNI lifecycle complexity, cross-compilation and debugging cost.
3. **Go engine in a separate local process:** normally higher complexity for an Android app, process lifecycle and IPC need justification; consider only if architecture requires it.
4. **Rewritten native networking component:** last resort for components that cannot practically be reused; document the cost and parity gap.

The preferred approach is the simplest option validated by a reproducible prototype. Avoid exporting the entire existing desktop application. Isolate a small platform-neutral API and keep Android UI/service ownership in Android code.

### Prototype gate

Before committing to an integration route, prove that a minimal Android app can:

- Build the actual relevant Go packages for the intended Android ABI(s).
- Invoke an engine initialization/health method from Kotlin/Java.
- Start and stop work without goroutine leaks or stale global state.
- Propagate logs, cancellation, and meaningful errors.
- Use the required networking APIs on a real Android runtime or a representative emulator.

A Go cross-compile alone does not satisfy this gate.

## 5. UI strategy comparison

| Strategy | Advantages | Risks | Initial position |
|---|---|---|---|
| Kotlin + Jetpack Compose (or other maintained native UI) | Strong Android lifecycle/permission integration, native accessibility/layout, straightforward service connection | Existing Svelte screens require recreation; two UI implementations exist | Preferred provisional choice if mobile UX and platform reliability outweigh visual code reuse |
| Existing Svelte UI inside Android WebView with Kotlin bridge | Reuses design tokens/components and frontend skills; may accelerate visual parity | Wails bindings must be replaced; WebView/native bridge complexity; web UI may feel less native; security boundary and lifecycle must be designed | Viable if frontend audit shows low desktop coupling and responsive mobile behavior |
| Web app/PWA only | Simple distribution and UI reuse | Cannot provide required system traffic capture and lifecycle behavior by itself | Insufficient for full Younblock functionality unless product scope changes |

Final choice must consider the actual frontend's Wails coupling, mobile readiness, desired maintenance model, and ability to call backend/service APIs safely.

## 6. Provisional recommendation

For an Android edition that aims to route traffic from supported applications rather than requiring per-browser manual proxy settings, investigate `VpnService` + a maintained userspace packet/forwarding layer + a small Go engine API as the primary candidate. Use a native Android UI unless audit evidence shows that retaining Svelte inside WebView provides a clear advantage without compromising integration.

This is **not yet an implementation approval**. Do not build the complete app until the source audit answers what protocol the existing relay accepts and a prototype proves the packet-to-relay path. If that path is too risky, present a concrete browser-specific fallback and clearly explain that it is a narrower product.

## 7. Required decision matrix

Score each viable candidate from 1 (poor) to 5 (strong), cite evidence, and weight network correctness and maintainability more highly than UI reuse.

| Criterion | Weight | Browser proxy | Android proxy | Local VPN/TUN | WebView-only |
|---|---:|---:|---:|---:|---:|
| Core Younblock behavior | 5 | To score | To score | To score | To score |
| Ability to reach actual relay | 5 | To score | To score | To score | To score |
| Traffic coverage matches product goal | 5 | To score | To score | To score | To score |
| Engineering feasibility | 4 | To score | To score | To score | To score |
| Lifecycle and reliability | 4 | To score | To score | To score | To score |
| Privacy clarity | 4 | To score | To score | To score | To score |
| Long-term maintenance | 4 | To score | To score | To score | To score |
| User setup friction | 3 | To score | To score | To score | To score |
| UI reuse | 2 | To score | To score | To score | To score |
| Performance/battery | 4 | To score | To score | To score | To score |

Do not make numerical scores look scientific when they are based on untested assumptions. Explain the evidence and remaining uncertainties.

## 8. Current authoritative documentation to check

- Android VPN guide: <https://developer.android.com/develop/connectivity/vpn>
- Android foreground services: <https://developer.android.com/develop/background-work/services/fgs>
- Android network security configuration: <https://developer.android.com/privacy-and-security/security-config>
- Go mobile package docs: <https://pkg.go.dev/golang.org/x/mobile>
- `gomobile` command: <https://pkg.go.dev/golang.org/x/mobile/cmd/gomobile>
- Go build constraints: <https://pkg.go.dev/cmd/go#hdr-Build_constraints>
- Wails repository/platform information: <https://github.com/wailsapp/wails>

Verify the current policy, API level, and tooling versions at implementation time.

## 9. Exit gate

Architecture selection is approved only after the repository audit is complete, the relay and traffic path are understood, integration choice is tested, and all remaining P0 risks have an explicit mitigation or a recorded no-go decision.

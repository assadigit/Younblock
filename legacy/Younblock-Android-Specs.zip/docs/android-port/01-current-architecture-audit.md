# 01 — Current Architecture Audit

**Status:** Template and audit checklist. Complete this with evidence from the actual repository before finalizing the Android design.

## 1. Audit objective

Identify the exact reusable networking logic, platform-specific integration, frontend/backend interface, configuration behavior, build tooling, and test coverage in the current Younblock implementation. Do not infer architecture from language statistics alone.

## 2. Repository state and inventory

Record before editing:

| Item | Finding | Evidence |
|---|---|---|
| Current branch | **To verify** | `git branch --show-current` |
| Worktree status | **To verify** | `git status --short --branch` |
| Remote URLs | **To verify** (redact credentials) | `git remote -v` |
| Latest commit | **To verify** | `git log -1 --oneline` |
| Main Go module(s) | **To verify** | `go.mod` path(s) |
| Frontend package manager and scripts | **To verify** | package manifest and lockfile |
| Wails version/configuration | **To verify** | `wails.json` or equivalent, `go.mod` |
| Existing test suites | **To verify** | test file inventory and CI |
| Existing release workflow | **To verify** | workflows, scripts, release docs |

Do not publish secrets from remote URLs, environment files, or build logs.

## 3. Required source trace

Build an execution trace from the UI's Connect/Disconnect action to the backend and back. Locate and document:

1. Application entry points and process lifecycle.
2. UI component and frontend-to-Go binding/event mechanism.
3. Connection controller/state machine.
4. Relay listener and accepted-connection path.
5. Secure DNS resolution and provider selection/fallback.
6. TLS ClientHello detection and splitting implementation.
7. Rules that pass unrelated traffic through unchanged, if present.
8. Connection test and what its latency value actually measures.
9. Automatic retries, repair behavior, timers, and cancellation.
10. Settings schema, defaults, persistence, validation, and migrations.
11. Windows proxy apply/restore/monitoring code.
12. Linux proxy apply/restore/monitoring code.
13. Any browser-specific mode and browser launching behavior.
14. Logging, diagnostics, version reporting, tray/desktop integration.
15. Build scripts and runtime dependencies, including Python, PowerShell, shell commands, generated binaries, or downloaded resources.

Use the actual file paths, function names, types, and dependency versions. Include line references or symbols where practical. Do not include sensitive user configuration values.

## 4. Component inventory template

For each component, complete one row:

| Component | Actual path/package | Responsibility | Platform/API dependencies | Tests | Android disposition | Evidence |
|---|---|---|---|---|---|---|
| Application entry point | To verify | To verify | To verify | To verify | Rewrite/adapter/reuse — decide from evidence | To add |
| Networking engine | To verify | To verify | To verify | To verify | Reuse/adapter/rewrite — decide from evidence | To add |
| Secure DNS | To verify | To verify | To verify | To verify | Reuse/adapter/rewrite — decide from evidence | To add |
| TLS ClientHello handling | To verify | To verify | To verify | To verify | Reuse/adapter/rewrite — decide from evidence | To add |
| Relay | To verify | To verify | To verify | To verify | Reuse/adapter/rewrite — decide from evidence | To add |
| Windows proxy adapter | To verify | To verify | Windows APIs | To verify | Do not reuse as Android system integration | To add |
| Linux proxy adapter | To verify | To verify | Linux APIs/tools | To verify | Do not reuse as Android system integration | To add |
| Wails and frontend bridge | To verify | To verify | Desktop runtime | To verify | Replace/adapt; Wails Android support must not be assumed | To add |
| Svelte/TypeScript frontend | To verify | To verify | Web frontend | To verify | Reuse in WebView or replace with native UI — decide after comparison | To add |
| Settings storage | To verify | To verify | OS/filesystem APIs | To verify | Migrate/adapt to Android storage | To add |
| Build/release system | To verify | To verify | Toolchain/OS | To verify | Add Android build lane without regressions | To add |

## 5. Go portability audit

Inspect all Go packages and record:

- Imports that are OS-specific or unavailable on Android.
- Build tags and files split by platform.
- Use of `syscall`, `unsafe`, cgo, C libraries, native binaries, filesystem assumptions, process execution, system proxies, interfaces, sockets, and low-level networking.
- Dependencies with Android/ARM64 limitations or external tool requirements.
- Global state and singleton assumptions that complicate lifecycle restart or tests.
- API surface suitable for a small platform-neutral engine package.
- Existing tests that can run under Android-targeted builds or in host-only tests.
- Licensing obligations if adding mobile or packet-processing dependencies.

Suggested inspection commands (adapt to the repo; do not assume all tools are installed):

```sh
go version
go env GOOS GOARCH CGO_ENABLED GOPROXY
go list ./...
go test ./...
go list -deps ./...
```

Cross-compilation alone is not proof that runtime networking works on Android.

## 6. Frontend and desktop-runtime audit

Determine whether the frontend can be built as static assets independently of Wails. Identify how it imports generated Wails bindings, accesses desktop-only APIs, persists state, shows dialogs, manages animations/reduced motion, and receives backend events.

For each dependency on a Wails-only API, record the mobile equivalent or recommend a native UI. Verify whether the frontend is actually responsive/mobile-ready before recommending reuse.

## 7. Existing desktop behavior baseline

List the commands to build and test Windows and Linux editions from a clean checkout. Capture current passing/failing results and environment limitations before Android edits. This baseline will be used for regression comparisons.

## 8. Findings summary (complete during Phase 1)

- Reusable components: **To verify**.
- Components requiring platform adapters: **To verify**.
- Components requiring rewrite: **To verify**.
- Critical dependencies and licensing: **To verify**.
- Existing test gaps: **To verify**.
- Desktop regression risks: **To verify**.
- Evidence references: **To add**.

## 9. Audit exit criteria

This audit is complete only when every major runtime component has an evidence-backed disposition, the real connection flow is understood, and the next agent can locate all relevant source files without guessing.

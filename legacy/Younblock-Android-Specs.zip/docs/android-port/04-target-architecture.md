# 04 — Target Android Architecture

**Status:** Provisional target architecture. Replace proposed module/package names with verified and agreed names during Phase 1.

## 1. Design goals

- Reuse portable and tested Younblock Go logic where feasible.
- Isolate Android APIs from desktop-only functionality.
- Keep the existing Windows/Linux build paths intact.
- Give the Android layer explicit ownership of permissions, foreground-service lifecycle, user-visible state, and settings UI.
- Ensure the engine reports real readiness and failures to the UI.
- Keep routing and protocol mechanics testable independently of UI code.
- Do not claim wider traffic coverage than the selected route and tests establish.

## 2. Proposed logical components

Names below are conceptual. Actual folders and packages must be chosen after the repository audit.

1. **Android UI** — connection action, status, settings, help, diagnostics, consent copy.
2. **Android application/state layer** — state transitions, settings validation, UI state projection, lifecycle reconciliation.
3. **Android network service** — owns service lifetime, VPN permission/establishment if applicable, notification, network changes, start/stop and cleanup.
4. **Routing adapter** — implements the approved traffic-ingress model (browser proxy or local VPN/TUN); owns Android-specific configuration.
5. **Userspace packet/stream adapter** — only for a TUN design; converts traffic into the transport accepted by the engine. Must be explicitly implemented and tested, not implied by TUN setup.
6. **Go engine facade** — narrow, stable cross-language interface exposing initialization, configuration, start, health, diagnostics, and stop.
7. **Reusable Go engine** — existing DNS, relay, TLS stream handling, connection checks, and other verified portable capabilities.
8. **Configuration repository** — Android-appropriate storage and validation; no secret material should be logged.
9. **Diagnostics/logging** — redacted, structured errors across Kotlin/Go boundary.

## 3. Proposed module boundaries

Illustrative layout only; adapt to the actual source tree and chosen build system:

```text
android/                         # Android Gradle project/module
  app/                           # manifest, UI, app lifecycle
  network/                       # VPNService/proxy adapter and routing lifecycle
  bridge/                        # generated bindings or JNI wrapper
internal/ or pkg/                # portable Go packages, based on current repo structure
  engine/                        # narrow platform-neutral engine API (proposed)
  ... existing Go packages ...
frontend/                        # existing desktop frontend; preserve for desktop
```

Do not physically move packages merely to match this diagram. First identify package imports and build constraints. A Go package should be shared only when it does not pull desktop-only runtime behavior into the Android build.

## 4. Proposed engine API contract

The exact signature depends on binding tool constraints. Preserve these semantics even if the syntax changes:

```text
Engine.Create(configuration) -> EngineHandle or actionable error
Engine.Start(context/options) -> start result or actionable error
Engine.HealthCheck() -> structured health result
Engine.Diagnostics() -> redacted diagnostic snapshot
Engine.UpdateConfiguration(validated configuration) -> result
Engine.Stop(context/timeout) -> result
Engine.Version() -> version/build metadata
```

Required contract behaviors:

- All operations return explicit success/error results; no hidden panics across JNI/bindings.
- Start is idempotent or explicitly rejects invalid transitions.
- Stop is safe to call repeatedly and waits for owned resources to terminate within a documented bound.
- Cancellation propagates to network operations and goroutines.
- No callback is invoked after its consumer has been disposed without a safe lifecycle mechanism.
- Configuration is validated before runtime reconfiguration.
- Errors have stable categories and safe user-facing messages; sensitive URLs, credentials, and request content are not emitted by default.
- The bridge documents which thread calls methods and how async events are delivered.
- Avoid exposing large internal Go object graphs to Kotlin/Java.

Example result categories (map to actual errors):

`PERMISSION_DENIED`, `INVALID_CONFIGURATION`, `ENGINE_START_FAILED`, `DNS_UNAVAILABLE`, `UPSTREAM_BLOCKED`, `ROUTING_FAILED`, `HEALTH_CHECK_FAILED`, `STOP_FAILED`, `UNSUPPORTED_TRAFFIC`, `UNKNOWN`.

Do not label every error as DNS failure or connectivity failure when the true source is unknown.

## 5. State ownership

The network service and engine must be the source of truth for the actual connection state. UI state is a projection of reported service/engine state, not a substitute for it.

Suggested high-level state flow:

```mermaid
stateDiagram-v2
    [*] --> Disconnected
    Disconnected --> AwaitingPermission: Connect requested
    AwaitingPermission --> Disconnected: Permission denied
    AwaitingPermission --> Starting: Permission granted / not required
    Starting --> Connected: Routing + engine + health check succeed
    Starting --> Error: Startup or health check fails
    Connected --> Recovering: Network/health failure detected
    Recovering --> Connected: Recovery and health check succeed
    Recovering --> Error: Recovery exhausted
    Error --> Starting: Retry requested
    Connected --> Stopping: Disconnect requested
    Starting --> Stopping: Cancel/start aborted
    Recovering --> Stopping: Disconnect requested
    Stopping --> Disconnected: Resources cleaned up
    Error --> Disconnected: Cleanup completed
```

Refine this state machine to align with current product behavior, and specify timeout/retry limits and service-death reconciliation.

## 6. Connect sequence (provisional)

```mermaid
sequenceDiagram
    actor User
    participant UI as Android UI
    participant Service as Android Network Service
    participant Route as Routing Adapter
    participant Bridge as Go Bridge
    participant Engine as Go Engine
    User->>UI: Tap Connect
    UI->>Service: Request start
    Service->>Service: Obtain required permission
    Service->>Route: Establish routing path
    Service->>Bridge: Initialize and start engine
    Bridge->>Engine: Start(config)
    Engine-->>Bridge: Startup result
    Route-->>Service: Route ready
    Service->>Engine: Health check
    Engine-->>Service: Verified result
    Service-->>UI: Connected with truthful status
```

Implement actual ordering according to the routing mechanism. The sequence may need to start the engine before enabling routes to prevent black-holing traffic; define rollback if any step fails.

## 7. Traffic flow (must be finalized after feasibility gate)

```mermaid
flowchart TD
    A[Supported browser or app traffic] --> B{Selected ingress model}
    B -->|Browser proxy| C[Browser proxy connection]
    B -->|VPN/TUN| D[Android TUN interface]
    D --> E[Userspace IP/TCP/UDP processor]
    C --> F[Verified relay/engine ingress]
    E --> F
    F --> G[Domain/traffic classification if implemented]
    G --> H[Secure DNS / destination resolution]
    H --> I[Approved TLS stream handling]
    I --> J[Upstream destination]
    J --> K[Response path]
    K --> F
    F --> C
    F --> E
```

This diagram is conceptual. The audit must correct the actual protocol path, especially whether destination resolution occurs before or after a local connection is accepted and whether the relay supports transparent TCP/UDP traffic.

## 8. Failure and rollback design

Startup should be treated as a transaction:

1. Validate settings and prerequisites.
2. Obtain user permission if required.
3. Initialize the engine and traffic adapter in a safe order.
4. Verify the routing state and a meaningful connection check.
5. Report Connected only after success.
6. On failure, stop partially initialized components, remove app-owned routes/interface, release resources, and report the primary error plus cleanup errors.

Disconnect must cancel active work, stop accepting new flows, close active resources according to policy, remove routes/interface, stop the engine, and reconcile service/UI state. Test every partial-start failure point.

## 9. Data and configuration

Use a versioned configuration schema. Define validated fields for DNS provider choices, traffic scope/mode, and other settings confirmed by the source audit. Do not copy desktop absolute paths, OS proxy state, or plaintext secrets into Android configuration by default.

Configuration rules:

- Use Android-appropriate private app storage.
- Separate user preferences from transient runtime state.
- Add migration logic for schema changes.
- Validate provider URLs/addresses and reject malformed values.
- Do not store credentials unless the existing verified requirements require them.
- Redact private values from diagnostics.

## 10. Desktop separation

Keep existing Windows/Linux adapters and Wails entry points available. Isolate shared Go logic only with minimal, justified refactors, platform-specific filenames/build constraints where appropriate, and desktop regression tests. Do not let an Android-specific dependency enter the default desktop build unintentionally.

## 11. Architecture exit criteria

Before implementation, settle: routing ingress, packet-to-relay mapping, TCP/UDP/IPv4/IPv6 policy, Go binding approach, UI approach, minimum Android API and ABI targets, lifecycle/notification behavior, settings schema, error contract, and rollback logic. Record each decision in `08-architecture-decisions.md`.

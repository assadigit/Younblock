# 02 — Android Requirements and Feature Matrix

**Status:** Initial product baseline. Feature details must be reconciled with the source audit and a verified Android routing architecture.

## 1. Product goal

Deliver an installable Android app that makes the existing Younblock functionality available on compatible Android devices, with honest explanations about which traffic is processed. Preserve the product's recognizable interaction model where suitable: one clear main connection control, real service state, actionable errors, settings, and diagnostics.

## 2. Scope principles

- Prioritize a correct, reliable core connection over feature count or cosmetic parity.
- Preserve existing Go logic when technically safe and maintainable.
- Mobile traffic interception and Android permissions are first-class product behaviors, not implementation details to hide.
- Do not promise that every Android browser or application is supported until tested.
- Do not silently change product privacy claims.
- Desktop features that have no meaningful Android equivalent may be deferred, but must be documented.

## 3. Priority definitions

- **P0 — Release blocker:** Required to call the Android build a usable core product.
- **P1 — First release if the chosen architecture supports it:** Expected functionality; if omitted, document and expose the limitation clearly.
- **P2 — Later:** Useful but not needed for initial release.
- **N/A:** Desktop-specific or irrelevant; document the reason.

## 4. Feature matrix

| ID | Feature / behavior | Initial priority | Acceptance criteria | Verification method |
|---|---|---:|---|---|
| AND-001 | Install and launch | P0 | APK installs on the declared supported API range and opens without crash | Install and launch on emulator/device |
| AND-002 | Connect/disconnect | P0 | UI reflects actual service state; rapid repeated taps do not create duplicate workers or inconsistent state | Lifecycle/integration tests and device smoke test |
| AND-003 | Permission and consent | P0 | Explain all sensitive Android networking permissions before requesting them; handle denial and revocation cleanly | Manual permission tests |
| AND-004 | Core traffic processing | P0 | At least the expressly supported traffic path traverses the selected Younblock engine and passes a real end-to-end test | Network integration tests |
| AND-005 | Accurate connection check | P0 | A successful UI state requires initialization plus a successful meaningful connectivity check; failure reasons are accurate | Failure injection and real connection test |
| AND-006 | Safe stop / cleanup | P0 | Stopping removes app-owned routing/resources and returns supported device traffic to normal routing without leaving a stuck service | Device and lifecycle tests |
| AND-007 | DNS behavior | P0 | Configured DNS behavior matches the documented implementation; provider failures are shown and do not silently fall back contrary to settings | DNS integration tests |
| AND-008 | TLS ClientHello handling | P0 if required by audited core mechanism | The proven implementation is exercised in the supported connection path; unsupported TLS cases fail safely | Targeted protocol integration tests |
| AND-009 | Retry and recovery | P1 | Temporary network/DNS failures are detected and bounded recovery is attempted without uncontrolled loops | Fault injection/network switching |
| AND-010 | Persistent settings | P1 | Supported settings survive app restart; invalid settings are rejected with actionable feedback | Storage and restart tests |
| AND-011 | Editable DNS providers | P1 | Provider list can be viewed, changed, validated, and restored to defaults if this feature is confirmed in current product | UI and DNS tests |
| AND-012 | YouTube traffic scope | P0 | Precisely defined supported YouTube request path works; product does not imply untested universal support | Browser/app matrix in test plan |
| AND-013 | Other websites / all traffic mode | P1 | If implemented, routing scope is explicit and real traffic tests prove what is included and excluded | Domain and traffic classification tests |
| AND-014 | Response-time display | P2 | Measurement label and calculation match what is measured; do not call an application round trip a generic network ping | Unit and UI tests |
| AND-015 | Status/error diagnostics | P0 | Errors distinguish at least permission, service startup, DNS, engine, upstream/network, and connectivity-check failures when detectable | Error mapping tests |
| AND-016 | Version/About | P2 | Version comes from the build/app metadata rather than a stale hard-coded value | Build metadata test/manual check |
| AND-017 | Help/privacy disclosure | P0 | Explain scope, limitations, DNS providers, and whether traffic is sent to remote infrastructure | Content and release review |
| AND-018 | Background operation | P0 for any connection that must persist when minimized | Connection remains functional only using a compliant service/lifecycle design; stop/revocation is handled | Device tests with screen off/app backgrounded |
| AND-019 | Network changes | P1 | Wi-Fi/mobile transitions trigger documented recovery or a clear failure state without stale “Connected” status | Network switch tests |
| AND-020 | IPv4 and IPv6 | P0 for claimed support | Either correctly supports each advertised family or clearly disables/declares an unsupported family without leaking or black-holing traffic | Dual-stack tests |
| AND-021 | TCP and UDP/QUIC | P0/P1 according to chosen scope | Support is explicitly scoped and tested; unsupported traffic does not produce false success | Protocol-level tests |
| AND-022 | Local network and bypass rules | P1 | Routing/exclusion behavior is documented and avoids recursive interception; local destinations behave as designed | LAN and loop tests |
| AND-023 | Responsive mobile UI | P1 | Main action, status, errors, and settings are usable on narrow phones, font scaling, rotation, and accessibility settings | Manual/device UI tests |
| AND-024 | Desktop regression | P0 | Existing Windows/Linux build and tests remain passing against baseline or regressions are explained | Baseline comparison |
| AND-025 | Build reproducibility | P0 | Build steps, required tools, exact APK output, version, and checksum are documented | Clean build verification |
| AND-026 | Two desktop UI editions | P2/N/A | Decide whether Classic edition has product value on Android; do not reproduce it automatically | Product/architecture decision |
| AND-027 | Desktop tray integration | N/A | Replace with Android notification/service affordance only if required by approved lifecycle design | Design review |
| AND-028 | Start on OS login | N/A or P2 | Reevaluate according to Android lifecycle and policy; do not carry desktop startup behavior across by assumption | Platform/policy review |

## 5. User-visible states

Define and test explicit states, at minimum:

- `Disconnected`
- `RequestingPermission` (when applicable)
- `Starting`
- `Connected` (only after engine and required verification succeed)
- `Checking` / `Recovering` (if applicable)
- `ConnectionNeedsAttention`
- `Stopping`
- `Error`

State names may differ in implementation. Transitions, ownership, and UI meaning must remain consistent. Never show Connected merely because a service object was created.

## 6. Acceptance scenarios

1. First launch: the app explains its purpose and limitations before requesting any system networking permission.
2. Permission denied: the app remains usable in a disconnected state and explains how to continue.
3. Connect success: service startup, routing configuration, engine readiness, and required verification complete before the UI reports Connected.
4. DNS failure: the UI identifies DNS/provider failure when detectable and does not label it a generic success.
5. Network blocked: failure is visible, the app can retry within documented limits, and status remains truthful.
6. User stops connection: app-owned service and routes are removed; normal networking resumes according to Android behavior.
7. Process/service interruption: returning to the app reconciles the UI with actual service state.
8. Unsupported traffic: documented fallback behavior occurs without silent data loss or false all-traffic claims.
9. Device restart: no unexpected network interception occurs unless a separately reviewed, compliant feature explicitly provides it.
10. Desktop regression: the Windows and Linux application still build and retain baseline functionality.

## 7. Requirement traceability

During implementation, extend the table below so each requirement maps to code and evidence:

| Requirement ID | Design section | Implementation files | Test name/result | Release note |
|---|---|---|---|---|
| AND-001 … AND-028 | To complete from final architecture | To complete | To complete | To complete |

## 8. Out of scope by default

- Creating a remote VPN server or claiming remote VPN capabilities.
- Hiding a public IP address or adding encryption that is not implemented.
- Circumventing Android security controls.
- Claiming guaranteed access on every filtered network.
- Rewriting desktop code unrelated to Android portability.
- Distributing a release build with invented signing credentials.

# 08 — Architecture Decision Records

**Status:** Initial decisions are constraints and provisional preferences, not proof that a technical path has been validated. Update records when evidence changes.

## ADR-0001 — Keep desktop app working; isolate Android integration

- **Status:** Accepted.
- **Context:** Younblock already ships on Windows and Linux; Android introduces different platform APIs and app lifecycle behavior.
- **Decision:** Add Android-specific project/integration code without making desktop builds depend on Android SDKs or platform services. Extract only genuinely reusable Go logic with minimal refactoring.
- **Alternatives:** Fork the full codebase; rewrite all platforms; force all platforms into one runtime.
- **Rationale:** Minimizes regression risk and preserves existing product value.
- **Consequences:** Shared interfaces and build tags may be needed; regression tests are required.
- **Revisit when:** Audit shows current source architecture prevents a clean boundary.

## ADR-0002 — Do not assume Wails is the Android application runtime

- **Status:** Accepted as a constraint.
- **Context:** Existing UI appears to be Svelte/TypeScript under Wails.
- **Decision:** The Android build must select a supported Android UI/container strategy independently; Wails desktop runtime must not be presumed Android-compatible.
- **Alternatives:** Attempt to use Wails unchanged; embed Svelte in WebView; recreate UI natively.
- **Rationale:** Runtime and native lifecycle compatibility must be explicitly proven.
- **Consequences:** Existing UI may be reused only through a separate WebView/static frontend route, or the mobile UI may be rebuilt.
- **Revisit when:** Source/toolchain audit finds an officially supported path that fits project requirements.

## ADR-0003 — Choose traffic ingress only after a real proof of concept

- **Status:** Proposed / decision blocked pending evidence.
- **Context:** Desktop behavior reportedly depends on OS proxy settings; equivalent Android-wide proxy control cannot be assumed.
- **Options:** Browser-specific proxy; Android user-configured proxy; local `VpnService` plus userspace processing; narrower controlled WebView experience.
- **Provisional preference:** Local `VpnService`/TUN architecture if transparent routing for supported applications is a product requirement. Browser-specific proxy is a possible lower-complexity fallback only if its narrower scope is acceptable.
- **Required evidence:** Existing relay protocol; packet-to-relay bridge; DNS and TLS byte-stream path; TCP/UDP/IPv4/IPv6 policy; no-loop behavior; start/stop cleanup; a real Android integration test.
- **Release gate:** No broad traffic-support claims until the proof of concept and network tests pass.
- **Consequences:** May require significant new Android-specific network code beyond Go compilation.
- **Decision owner:** Coding agent after repository audit; record the evidence and date.

## ADR-0004 — Prefer a narrow Go engine API

- **Status:** Proposed, pending dependency/ABI prototype.
- **Context:** The majority of the described repository is Go, but the whole desktop app may depend on Wails and OS APIs.
- **Decision:** Expose only the required platform-neutral engine operations through a small API, rather than binding the entire desktop backend.
- **Options:** `gomobile` AAR; c-shared/JNI; IPC process; rewrite incompatible component.
- **Provisional preference:** Use the simplest path demonstrated by a working minimal Android prototype.
- **Required evidence:** Package compatibility, lifecycle/cancellation correctness, ABI build, callbacks/errors, and runtime test.
- **Consequences:** Engine/package seams may need to be refactored with desktop regression coverage.

## ADR-0005 — UI choice must account for mobile lifecycle, not only reuse

- **Status:** Proposed.
- **Options:** Native Kotlin UI (e.g. Compose); Svelte in WebView with a Kotlin bridge.
- **Provisional preference:** Native Android UI when connection service, permissions, state reconciliation, and accessibility are priorities; choose WebView only if audit shows frontend is portable, responsive, and worth maintaining.
- **Required evidence:** Existing frontend coupling, mobile responsiveness, bridge design, build complexity, accessibility testing, and maintenance cost.
- **Consequences:** A native UI duplicates visual components; WebView retains a web/native security boundary and extra bridge complexity.

## ADR-0006 — Never show a false Connected state

- **Status:** Accepted.
- **Decision:** Connected must represent confirmed service/route/engine readiness and the defined health check. UI animation or object creation alone is insufficient.
- **Consequences:** State machine and failure tests are mandatory; the app may show a longer Starting/Checking state or a clear failure when a network cannot be used.

## ADR-0007 — Privacy claims must follow implementation evidence

- **Status:** Accepted.
- **Decision:** Do not claim IP masking, extra encryption, anonymity, remote VPN routing, or universal filtering bypass unless implemented and verified. Describe the selected traffic scope and DNS providers.
- **Consequences:** Add reviewable disclosure content and prevent unsupported marketing language.

## Decision-change procedure

When changing a provisional decision, include the new evidence, the alternatives reconsidered, affected files/requirements/tests, and impact on user-visible behavior. Update this file and `README.md` before implementing dependent work.
